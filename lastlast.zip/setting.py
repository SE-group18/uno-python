import card_logic
import display_funct
import game_control
import Main_Decision_Tree
import pygame
from pygame.locals import *s

def setting_screen():
    pass