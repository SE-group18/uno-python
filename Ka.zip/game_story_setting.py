from deck_gen import gen_rand_deck
import display_funct
import game_AI
import game_classes
import game_logic
import Card_Choose_Tree
import Card_Guess_Tree
import Main_Decision_Tree

def test_setting(deck, player):
    player.grab_cards(deck, 7)
    player2AI = game_AI.make_AI_basic(deck, "player_2AI", 7)
    Players = [player, player2AI]
    return Players


def setting_A(deck, player):
    return 0

def setting_B(deck, player):
    player.grab_cards(deck, 15)
    player2AI = game_AI.make_AI_B(deck, "player_2AI", 0)
    player3AI = game_AI.make_AI_B(deck, "player_3AI", 0)
    player4AI = game_AI.make_AI_B(deck, "player_4AI", 0)
    
    Players = [player, player2AI, player3AI, player4AI]
    return Players


def setting_D():
    # 기술카드 없이
    # 상대 카드가 다 보이게
    # 두턴씩
    # 3판 2선
    return 0

