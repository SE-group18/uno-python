from deck_gen import gen_rand_deck
import display_funct
import game_AI
import game_classes
import game_logic

# loop for allowing multiple games to be restarted
def main():
    while True:
        # initilizing the board to be used within the game
        display_funct.title_screen()

if __name__ == "__main__":
    main()